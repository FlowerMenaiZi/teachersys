<template>
  evenStudyCheck
</template>

<script lang="ts">
  import {defineComponent} from 'vue'

  export default defineComponent({
    name: "evenStudyCheck",
    setup() {
      return {}
    }
  })
</script>

<style scoped>

</style>