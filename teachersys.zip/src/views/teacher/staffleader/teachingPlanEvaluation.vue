<template>
  
</template>

<script lang="ts">
  import {defineComponent} from 'vue'

  export default defineComponent({
    name: "teachingPlanEvaluation",
    setup() {
      return {}
    }
  })
</script>

<style scoped>

</style>