<template>
  
</template>

<script lang="ts">
  import {defineComponent} from 'vue'

  export default defineComponent({
    name: "teachingPlanEvaluationTotal",
    setup() {
      return {}
    }
  })
</script>

<style scoped>

</style>